module.exports = {
  plugins: {
    'postcss-nested': {}, // Add postcss-nested plugin
    tailwindcss: {},
    autoprefixer: {},
  },
}
