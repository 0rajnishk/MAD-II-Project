<template>
    <!-- FOOTER  -->
    <footer class="flex-1 p-4 left-m bg-gradient-to-r from-midnight-blue to-sunset-orange" id="footer">
        <!-- SUB FOOTER -->
        <div class="bg-gradient-to-r from-midnight-blue to-sunset-orange text-center p-16">
            <div class="bg-gradient-to-r from-midnight-blue to-sunset-orange text-center p-16">
                <p class="text-4xl md:text-6xl font-bold text-platinum-white mb-4 ">
                    Harmonize Your World, One Song at a Time!
                </p>
                <p class="text-xl md:text-3xl font-medium text-platinum-white mb-2">
                    Embrace the Rhythm
                </p>
                <p class="text-lg md:text-2xl text-platinum-white italic">
                    by Discovering Music
                </p>
            </div>

            <br>
            <!-- TICK MARK ITEMS -->
            <!-- <div class="grid grid-cols-2 md:grid-cols-4 h-full items-center justify-center"> -->
            <div class="flex items-center justify-evenly">
                <div class="flex items-center">
                    <svg class="w-4 md:w-4 pr-0 md:pr-1" viewBox="0 -0.5 25 25" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                        <g id="SVGRepo_iconCarrier">
                            <path d="M5.5 12.5L10.167 17L19.5 8" stroke="#D1D5DB" stroke-width="2.5"
                                stroke-linecap="round" stroke-linejoin="round"></path>
                        </g>
                    </svg>
                    <span class="text-xs md:text-s text-gray-100">Tune Unity</span>
                </div>
                <div class="flex items-center">
                    <svg class="w-4 md:w-4 pr-0 md:pr-1" viewBox="0 -0.5 25 25" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                        <g id="SVGRepo_iconCarrier">
                            <path d="M5.5 12.5L10.167 17L19.5 8" stroke="#D1D5DB" stroke-width="2.5"
                                stroke-linecap="round" stroke-linejoin="round"></path>
                        </g>
                    </svg>
                    <span class="text-xs md:text-s text-gray-100">Harmonic Flux</span>
                </div>
                <div class="flex items-center">
                    <svg class="w-4 md:w-4 pr-0 md:pr-1" viewBox="0 -0.5 25 25" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                        <g id="SVGRepo_iconCarrier">
                            <path d="M5.5 12.5L10.167 17L19.5 8" stroke="#D1D5DB" stroke-width="2.5"
                                stroke-linecap="round" stroke-linejoin="round"></path>
                        </g>
                    </svg>
                    <span class="text-xs md:text-s text-gray-100">Rhythmic Nexus</span>
                </div>
                <div class="flex items-center">
                    <svg class="w-4 md:w-4 pr-0 md:pr-1" viewBox="0 -0.5 25 25" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                        <g id="SVGRepo_iconCarrier">
                            <path d="M5.5 12.5L10.167 17L19.5 8" stroke="#D1D5DB" stroke-width="2.5"
                                stroke-linecap="round" stroke-linejoin="round"></path>
                        </g>
                    </svg>
                    <span class="text-xs md:text-s text-gray-100">Melodic Merge</span>
                </div>
            </div>
        </div>

        <!-- FOOTER -->
        <div class="bg-black text-gray-700 p-10 flex flex-col md:flex-row justify-between">
            <!-- Column 1 -->
            <div class="footer-column mb-8 md:mb-0">
                <div>
                    <a href="/"><img src="../assets/img/logo.webp" alt="" class="w-36"></a>
                    <div class="flex space-x-4 mt-10">
                    </div>
                </div>
            </div>
            <!-- Column 2 -->
            <div class="footer-column mb-8 md:mb-0">
                <h3 class="text-lg font-semibold mb-3 text-white">The Music</h3>
                <ul class="list-none p-0 text-sm">
                    <li><a href="#" class="text-platinum-white hover:text-sunset-orange font-semibold mb-1">About Us</a>
                    </li>

                    <li><a href="#" class="text-platinum-white hover:text-sunset-orange font-semibold mb-1">Contact
                            Us</a></li>
                    <li><a href="#" class="text-platinum-white hover:text-sunset-orange font-semibold mb-1">Careers</a>
                    </li>
                    <li><a href="#" class="text-platinum-white hover:text-sunset-orange font-semibold mb-1">Privacy
                            Policy</a></li>
                </ul>
            </div>
            <!-- Column 3 -->
            <div class="footer-column mb-8 md:mb-0">
                <h3 class="text-lg font-semibold mb-4 text-white">Get in Touch</h3>
                <!-- ADDRESS -->
                <div class="flex items-center mb-2">
                    <svg class="mt-[5px] w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                        <g id="SVGRepo_iconCarrier">
                            <path
                                d="M12 21C15.5 17.4 19 14.1764 19 10.2C19 6.22355 15.866 3 12 3C8.13401 3 5 6.22355 5 10.2C5 14.1764 8.5 17.4 12 21Z"
                                stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path
                                d="M12 13C13.6569 13 15 11.6569 15 10C15 8.34315 13.6569 7 12 7C10.3431 7 9 8.34315 9 10C9 11.6569 10.3431 13 12 13Z"
                                stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        </g>
                    </svg>
                    <p class="text-gray-300">The Music,
                        IIT Madras, Guindy, Chennai</p>

                </div>
                <!-- EMAIL -->
                <div class="flex items-center mb-2">
                    <svg class="mt-[5px] w-5 h-5 mr-2" version="1.1" id="_x32_" xmlns="http://www.w3.org/2000/svg"
                        xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512 512" xml:space="preserve"
                        fill="#ffffff">
                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                        <g id="SVGRepo_iconCarrier">
                            <g>
                                <path class="st0"
                                    d="M440.917,67.925H71.083C31.827,67.925,0,99.752,0,139.008v233.984c0,39.256,31.827,71.083,71.083,71.083 h369.834c39.255,0,71.083-31.827,71.083-71.083V139.008C512,99.752,480.172,67.925,440.917,67.925z M178.166,321.72l-99.54,84.92 c-7.021,5.992-17.576,5.159-23.567-1.869c-5.992-7.021-5.159-17.576,1.87-23.567l99.54-84.92c7.02-5.992,17.574-5.159,23.566,1.87 C186.027,305.174,185.194,315.729,178.166,321.72z M256,289.436c-13.314-0.033-26.22-4.457-36.31-13.183l0.008,0.008l-0.032-0.024 c0.008,0.008,0.017,0.008,0.024,0.016L66.962,143.694c-6.98-6.058-7.723-16.612-1.674-23.583c6.057-6.98,16.612-7.723,23.582-1.674 l152.771,132.592c3.265,2.906,8.645,5.004,14.359,4.971c5.706,0.017,10.995-2.024,14.44-5.028l0.074-0.065l152.615-132.469 c6.971-6.049,17.526-5.306,23.583,1.674c6.048,6.97,5.306,17.525-1.674,23.583l-152.77,132.599 C282.211,284.929,269.322,289.419,256,289.436z M456.948,404.771c-5.992,7.028-16.547,7.861-23.566,1.869l-99.54-84.92 c-7.028-5.992-7.861-16.546-1.869-23.566c5.991-7.029,16.546-7.861,23.566-1.87l99.54,84.92 C462.107,387.195,462.94,397.75,456.948,404.771z">
                                </path>
                            </g>
                        </g>
                    </svg>
                    <a href="mailto:Teamrunverve@gmail.com" class="text-gray-300">0rajnishk@gmail.com</a>
                </div>
                <!-- Mobile -->
                <div class="flex items-center mb-2">
                    <svg viewBox="0 0 24 24" class="mt-[5px] w-5 h-5 mr-2" fill="none"
                        xmlns="http://www.w3.org/2000/svg" stroke="#FFFFFF">
                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                        <g id="SVGRepo_iconCarrier">
                            <path
                                d="M3 5.5C3 14.0604 9.93959 21 18.5 21C18.8862 21 19.2691 20.9859 19.6483 20.9581C20.0834 20.9262 20.3009 20.9103 20.499 20.7963C20.663 20.7019 20.8185 20.5345 20.9007 20.364C21 20.1582 21 19.9181 21 19.438V16.6207C21 16.2169 21 16.015 20.9335 15.842C20.8749 15.6891 20.7795 15.553 20.6559 15.4456C20.516 15.324 20.3262 15.255 19.9468 15.117L16.74 13.9509C16.2985 13.7904 16.0777 13.7101 15.8683 13.7237C15.6836 13.7357 15.5059 13.7988 15.3549 13.9058C15.1837 14.0271 15.0629 14.2285 14.8212 14.6314L14 16C11.3501 14.7999 9.2019 12.6489 8 10L9.36863 9.17882C9.77145 8.93713 9.97286 8.81628 10.0942 8.64506C10.2012 8.49408 10.2643 8.31637 10.2763 8.1317C10.2899 7.92227 10.2096 7.70153 10.0491 7.26005L8.88299 4.05321C8.745 3.67376 8.67601 3.48403 8.55442 3.3441C8.44701 3.22049 8.31089 3.12515 8.15802 3.06645C7.98496 3 7.78308 3 7.37932 3H4.56201C4.08188 3 3.84181 3 3.63598 3.09925C3.4655 3.18146 3.29814 3.33701 3.2037 3.50103C3.08968 3.69907 3.07375 3.91662 3.04189 4.35173C3.01413 4.73086 3 5.11378 3 5.5Z"
                                stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        </g>
                    </svg>
                    <a href="tel:+919716463164" class="text-gray-300">+91 947196192*</a>
                </div>
            </div>
            <!-- COLUMN FOUR -->
            <div class="footer-column">
                <div>
                    <!-- APP STORE & PLAY STORE -->
                    <!-- <img src="../assets/img/app-store-badge-white.png.png" alt="" class="mb-2">
                    <img src="../assets/img/google-play-badge-white.png.png" alt="" class="mb-2"> -->
                    <div class="flex items-center">
                        <!-- FB, INSTA, TWITTER, PINTEREST, DRIBBLE -->
                        <!-- <img src="../assets/img/twitter.svg" alt="" class="mr-2">
                        <img src="../assets/img/youtube.svg" alt="" class="mr-2">
                        <img src="../assets/img/instagram.svg" alt="" class="mr-2">
                        <img src="../assets/img/pinterest.svg" alt="" class="mr-2">
                        <img src="../assets/img/dribble.svg" alt="" class="mr-2"> -->
                    </div>
                    <p class="inline-block mt-2 text-sm text-gray-300">
                        <a href="" class="md:inline-block md:whitespace-nowrap md:mr-0 hover:underline  ">The Music</a>
                        &copy;
                        2023
                    </p>
                </div>
            </div>
        </div>
    </footer>
</template>
  
<script>
export default {
    name: 'App',
}
</script>

