<template>
    <br>
    <br>
    <br>
    <div class="bg-midnight-blue-500 p-8 rounded-lg shadow-lg max-w-xl mx-auto" style="background-color: #00203F;">
        <h2 class="text-3xl font-semibold text-platinum-white mb-6" style="color: #EAEAEA;">Edit Song</h2>


        <form @submit.prevent="submitForm" class="grid grid-cols-1 gap-4">

            <div class="grid grid-cols-2 gap-4">
                <div class="mb-4">
                    <label for="songName" class="block text-platinum-white text-sm font-medium mb-1"
                        style="color: #EAEAEA;">Song Name</label>
                    <input v-model="formData.name" type="text" id="songName" name="songName"
                        class="w-full px-4 py-2.5 border rounded-md focus:outline-none focus:border-electric-cyan-500"
                        placeholder="Enter song name" style="border-color: #ADEFD1;" />
                </div>

                <div class="mb-4">
                    <label for="singer" class="block text-platinum-white text-sm font-medium mb-1"
                        style="color: #EAEAEA;">Singer</label>
                    <input v-model="formData.singer" type="text" id="singer" name="singer"
                        class="w-full px-4 py-2.5 border rounded-md focus:outline-none focus:border-electric-cyan-500"
                        placeholder="Enter singer name" style="border-color: #ADEFD1;" />
                </div>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div class="mb-4">
                    <label for="genre" class="block text-platinum-white text-sm font-medium mb-1"
                        style="color: #EAEAEA;">Genre</label>
                    <input v-model="formData.genre" type="text" id="genre" name="genre"
                        class="w-full px-4 py-2.5 border rounded-md focus:outline-none focus:border-electric-cyan-500"
                        placeholder="Enter genre" style="border-color: #ADEFD1;" />
                </div>
                <div class="mb-4">
                    <label for="album" class="block text-platinum-white text-sm font-medium mb-1"
                        style="color: #EAEAEA;">Album</label>
                    <select v-model="formData.album_id" id="album" name="album"
                        class="w-full px-4 py-2.5 border rounded-md focus:outline-none focus:border-electric-cyan-500"
                        style="border-color: #ADEFD1;">
                        <option value="formData.album_id">Select Album</option>
                        <option v-for="album in albums" :key="album.id" :value="album.id">{{ album.name }}</option>
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div class="mb-4">
                    <label for="audioFile" class="block text-platinum-white text-sm font-medium mb-1"
                        style="color: #EAEAEA;">Audio File</label>
                    <input type="file" id="audioFile" name="audioFile"
                        class="w-full px-4 py-2.5 border rounded-md focus:outline-none focus:border-electric-cyan-500"
                        @change="convertToBase64('audio_file', $event)" />
                </div>



                <div class="mb-4">
                    <label for="image" class="block text-platinum-white text-sm font-medium mb-1"
                        style="color: #EAEAEA;">Image</label>
                    <input type="file" id="image" name="image"
                        class="w-full px-4 py-2.5 border rounded-md focus:outline-none focus:border-electric-cyan-500"
                        @change="convertToBase64('image', $event)" />
                </div>
            </div>
            <div class="mb-4">
                <label for="lyrics" class="block text-platinum-white text-sm font-medium mb-1"
                    style="color: #EAEAEA;">Lyrics</label>
                <textarea v-model="formData.lyrics" id="lyrics" name="lyrics"
                    class="w-full px-4 py-2.5 border rounded-md focus:outline-none focus:border-electric-cyan-500"
                    placeholder="Enter lyrics" style="border-color: #ADEFD1;"></textarea>
            </div>



            <div class="flex justify-center">
                <button type="submit" @click="updateSong()"
                    class="bg-sunset-orange text-platinum-white px-6 py-3 rounded-md font-medium hover:bg-sunset-orange-dark"
                    style="background-color: #F66B0E; color: #EAEAEA;">
                    Update Song
                </button>
            </div>
        </form>
    </div>
    <br>
</template>

<script>
export default {
    data() {
        return {
            formData: {
                name: '',
                singer: '',
                genre: '',
                audio_file: '',
                image: '',
                lyrics: '',
                album_id: '',
            },
            albums: [],
        };
    },
    props: {
        songId: Number,
    },
    created() {
        this.fetchSong(this.songId);
        this.fetchAlbums();
    },
    methods: {
        async fetchSong(songId) {
            console.log(songId);
            const token = localStorage.getItem('token');
            console.log(this.formData);

            try {
                const response = await fetch(`http://127.0.0.1:8000/api/songs/audio/${songId}?audio=0`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`,
                        'Accept': 'application/json',
                    },
                });
                const data = await response.json();
                if (data.status) {
                    console.log(data.msg.name);
                    console.log('Song Fetched successfully');
                    this.formData.name = data.msg.name;
                    this.formData.singer = data.msg.singer;
                    this.formData.genre = data.msg.genre;
                    this.formData.lyrics = data.msg.lyrics;
                    this.formData.album_id = data.msg.album_id;
                } else {
                    console.log(data.error);
                }
            } catch (error) {
                console.error('Error fetching song:', error);
                console.log('Error fetching song!!!');
            }
        },

        async updateSong() {
            const token = localStorage.getItem('token');
            console.log(this.formData);

            try {
                const response = await fetch(`http:////127.0.0.1:8000/api/songs/audio/${this.songId}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`,
                        'Accept': 'application/json',
                    },
                    body: JSON.stringify(this.formData),
                });
                const data = await response.json();
                if (data.status) {
                    console.log('Song added successfully:', data);
                    console.log('Song added successfully!!!');
                }
            } catch (error) {
                console.error('Error adding song:', error);
                console.log('Error adding song!!!');
            }
        },

        async fetchAlbums() {
            console.log('fetching albums')
            const token = localStorage.getItem('token');
            try {
                const response = await fetch(`http:////127.0.0.1:8000/api/albums`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`,
                        'Accept': 'application/json',
                    },

                });
                const data = await response.json();
                if (data.status) {
                    console.log(data.msg)
                    console.log('albums fetched successfully')
                    this.albums = data.msg;
                    this.loading = false;
                } else {
                    console.log(data.error);
                }
            } catch (error) {
                console.error('Error fetching songs:', error);
            }
        },
        convertToBase64(key, event) {
            return new Promise((resolve, reject) => {
                const file = event.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        this.formData[key] = e.target.result;
                        resolve();
                    };
                    reader.onerror = reject;
                    reader.readAsDataURL(file);
                } else {
                    resolve();
                }
            });
        },

    },

};
</script>
